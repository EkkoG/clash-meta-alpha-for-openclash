## Embedded go-shadowsocks2

from https://github.com/Dreamacro/go-shadowsocks2

origin https://github.com/riobard/go-shadowsocks2
