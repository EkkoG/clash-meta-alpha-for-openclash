package constant

var (
	Meta      = true
	Version   = "1.10.0"
	BuildTime = "unknown time"
	ClashName = "clash.meta"
)
